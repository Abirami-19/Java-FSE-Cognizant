// application.properties

logging.level.org.springframework=info
logging.level.com.cognizant=debug

logging.level.org.hibernate.SQL=trace
logging.level.org.hibernate.type.descriptor.sql=trace

spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/ormlearn
spring.datasource.username=root
spring.datasource.password=root

spring.jpa.hibernate.ddl-auto=validate
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL5Dialect